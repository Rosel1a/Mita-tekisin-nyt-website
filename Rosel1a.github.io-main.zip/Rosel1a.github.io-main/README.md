Tämä sisältää WEB- ja mobiililkäyttöliittymät kurssilla tehdyn nettisivuston
https://rosel1a.github.io/
